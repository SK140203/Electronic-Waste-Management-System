<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="dashboard.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
               


        <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-files-o"></i>
                        <span>Product Requests</span>
                    </a>
                    <ul class="sub">
                        <li><a href="new-requests.php">New</a></li>
                        <li><a href="collect-products.php">Collected</a></li>
                        <li><a href="sentforcycle-products.php">Sent For Recycle</a></li>
                        <li><a href="recycled-products.php">Recycled</a></li>
                          <li><a href="rejected-products.php">Rejected</a></li>
                           <li><a href="all-assigned-request.php">All</a></li>
                    </ul>
                </li>
                 
                                
                             
                         <li><a href="search.php"><i class="fa fa-search"></i>
                        <span>Search</span>
                    </a>
                </li>
              
                
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>