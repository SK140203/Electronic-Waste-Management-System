<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="dashboard.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
               

<li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-th"></i>
                        <span>List Your Products</span>
                    </a>
                    <ul class="sub">
                        <li><a href="add-product-details.php">Add Product</a></li>
                        <li><a href="manage-product-details.php">Manage Product</a></li>
                    </ul>
                </li>

        

                         <li>
                    <a class="active" href="all-products-status.php">
                        <i class="fa fa-th"></i>
                        <span>Product Status</span>
                    </a>
                </li>
                                
                             
                         <li>
                    <a class="active" href="search.php">
                        <i class="fa fa-search"></i>
                        <span>Search</span>
                    </a>
                </li>
              
                
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>