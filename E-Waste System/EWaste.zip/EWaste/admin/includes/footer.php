<div class="footer">
			<div class="wthree-copyright">
			  <p> Electronic Waste System. All rights reserved.</p>
			</div>
		  </div>