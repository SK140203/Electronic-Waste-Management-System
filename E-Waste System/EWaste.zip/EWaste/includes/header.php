<header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <a class="navbar-brand" href="index.php">
            <span>
              E-Waste Management System
            </span>
          </a>

          <div class="navbar-collapse" id="">
            <div class="d-none d-lg-flex ml-auto flex-column flex-lg-row align-items-center">
              <ul class="navbar-nav  ">
                <li class="nav-item">
                  <a class="nav-link" href="admin/login.php">
                    <img src="images/login.png" alt="" />
                    <span>Admin</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="employee/login.php">
                    <img src="images/signup.png" alt="" />
                    <span>Recycler</span>
                  </a>
                </li>
                 <li class="nav-item">
                  <a class="nav-link" href="users/login.php">
                    <img src="images/signup.png" alt="" />
                    <span>User</span>
                  </a>
                </li>
              </ul>
             
            </div>

        
           
          </div>
        </nav>
      </div>
    </header>