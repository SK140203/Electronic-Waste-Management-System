

		  <section class="container-fluid footer_section">
 
       <p> E-Waste Management System. All rights reserved.</p>
  
  </section>